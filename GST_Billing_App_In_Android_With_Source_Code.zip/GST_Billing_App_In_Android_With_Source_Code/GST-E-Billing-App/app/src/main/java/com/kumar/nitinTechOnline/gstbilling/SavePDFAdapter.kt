package com.kumar.nitinTechOnline.gstbilling

import android.content.Context
import android.database.Cursor
import com.kumar.nitinTechOnline.gstbilling.SavePDFActivity.Companion.printTotalDetails
import android.support.v7.widget.RecyclerView
import com.kumar.nitinTechOnline.gstbilling.SavePDFAdapter.SavePDFHolder
import android.view.ViewGroup
import android.view.LayoutInflater
import android.view.View
import com.kumar.nitinTechOnline.gstbilling.R
import com.kumar.nitinTechOnline.gstbilling.data.GSTBillingContract
import com.kumar.nitinTechOnline.gstbilling.utils.PriceUtils
import com.kumar.nitinTechOnline.gstbilling.SavePDFActivity
import android.widget.TextView

/**
 * Created by Ajay on 8/28/2017.
 */
class SavePDFAdapter(private val mContext: Context, private var mCursor: Cursor?) :
    RecyclerView.Adapter<SavePDFHolder>() {
    private var totalQty = 0
    private var totalTaxableValue = 0f
    private var totalSingleGst = 0f
    private var totalAmount = 0f
    fun swapCursor(newCursor: Cursor?) {
        mCursor = newCursor
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SavePDFHolder {
        val view =
            LayoutInflater.from(mContext).inflate(R.layout.single_item_pdf_layout, parent, false)
        return SavePDFHolder(view)
    }

    override fun onBindViewHolder(holder: SavePDFHolder, position: Int) {
        if (mCursor!!.moveToPosition(position)) {
            val idValue =
                mCursor!!.getInt(mCursor!!.getColumnIndex(GSTBillingContract.GSTBillingCustomerEntry._ID))
            val itemDescriptionValue =
                mCursor!!.getString(mCursor!!.getColumnIndex(GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_COLUMN_ITEM_DESCRIPTION))
            val finalPriceValue =
                mCursor!!.getFloat(mCursor!!.getColumnIndex(GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_COLUMN_FINAL_PRICE))
            val quantityValue =
                mCursor!!.getInt(mCursor!!.getColumnIndex(GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_COLUMN_QUANTITY))
            val taxSlabValue =
                mCursor!!.getInt(mCursor!!.getColumnIndex(GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_COLUMN_TAX_SLAB))
            val priceUtils = PriceUtils(finalPriceValue, quantityValue, taxSlabValue)
            val rateValue = priceUtils.rate
            val taxableValueValue = priceUtils.taxableValue
            val singleGstValue = priceUtils.singleGst
            holder.itemPdf.text = itemDescriptionValue
            holder.snoPdf.text = String.format("%02d", idValue)
            holder.qtyPdf.text = quantityValue.toString()
            holder.ratePdf.text = String.format("%.2f", rateValue)
            holder.taxableValuePdf.text = String.format("%.2f", taxableValueValue)
            holder.taxSlabPdf.text = "$taxSlabValue%"
            holder.cgstPdf.text = String.format("%.2f", singleGstValue)
            holder.sgstPdf.text = String.format("%.2f", singleGstValue)
            totalQty += quantityValue
            totalTaxableValue += taxableValueValue
            totalSingleGst += singleGstValue
            totalAmount += finalPriceValue * quantityValue
            if (position == itemCount - 1) {
                printTotalDetails(totalQty, totalTaxableValue, totalSingleGst, totalAmount)
            }
        }
    }

    override fun getItemCount(): Int {
        return if (mCursor == null) {
            0
        } else {
            mCursor!!.count
        }
    }

    inner class SavePDFHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var snoPdf: TextView
        var itemPdf: TextView
        var ratePdf: TextView
        var qtyPdf: TextView
        var taxableValuePdf: TextView
        var taxSlabPdf: TextView
        var cgstPdf: TextView
        var sgstPdf: TextView

        init {
            snoPdf = itemView.findViewById(R.id.pdf_serial_number) as TextView
            itemPdf = itemView.findViewById(R.id.pdf_item) as TextView
            ratePdf = itemView.findViewById(R.id.pdf_rate) as TextView
            qtyPdf = itemView.findViewById(R.id.pdf_qty) as TextView
            taxableValuePdf = itemView.findViewById(R.id.pdf_taxable_value) as TextView
            taxSlabPdf = itemView.findViewById(R.id.pdf_tax_slab) as TextView
            cgstPdf = itemView.findViewById(R.id.pdf_cgst) as TextView
            sgstPdf = itemView.findViewById(R.id.pdf_sgst) as TextView
        }
    }
}