package com.kumar.nitinTechOnline.gstbilling

import android.support.v7.app.AppCompatActivity
import android.widget.EditText
import android.os.Bundle
import com.kumar.nitinTechOnline.gstbilling.R
import android.content.SharedPreferences
import android.preference.PreferenceManager
import com.kumar.nitinTechOnline.gstbilling.SetupPasswordActivity
import android.widget.Toast
import android.content.Intent
import android.widget.Button
import com.kumar.nitinTechOnline.gstbilling.BillsActivity

class SetupPasswordActivity : AppCompatActivity() {
    var businessName: EditText? = null
    var businessAddress: EditText? = null
    var businessContact: EditText? = null
    var newPass: EditText? = null
    var confirmPass: EditText? = null
    var setupPass: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup_password)
        businessName = findViewById(R.id.setup_business_value) as EditText
        businessAddress = findViewById(R.id.setup_business_address_value) as EditText
        businessContact = findViewById(R.id.setup_business_contact_value) as EditText
        newPass = findViewById(R.id.setup_new_password_value) as EditText
        confirmPass = findViewById(R.id.setup_confirm_password_value) as EditText
        setupPass = findViewById(R.id.setup_password_btn) as Button
        setupPass!!.setOnClickListener {
            val businessNameValue = businessName!!.text.toString()
            val businessAddressValue = businessAddress!!.text.toString()
            val businessContactValue = businessContact!!.text.toString()
            val newPassword = newPass!!.text.toString()
            val confirmPassword = confirmPass!!.text.toString()
            if (newPassword == confirmPassword) {
                val sharedPreferences =
                    PreferenceManager.getDefaultSharedPreferences(this@SetupPasswordActivity)
                val editor = sharedPreferences.edit()
                editor.putString(SETUP_BUSINESS_NAME_KEY, businessNameValue)
                editor.putString(SETUP_BUSINESS_ADDRESS_KEY, businessAddressValue)
                editor.putString(SETUP_BUSINESS_CONTACT_KEY, businessContactValue)
                editor.putString(SETUP_PASSWORD_KEY, newPassword)
                editor.apply()
                Toast.makeText(
                    applicationContext,
                    getString(R.string.setup_password_set),
                    Toast.LENGTH_SHORT
                ).show()
                startActivity(Intent(this@SetupPasswordActivity, BillsActivity::class.java))
                finish()
            } else {
                Toast.makeText(
                    applicationContext,
                    getString(R.string.setup_password_error),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    companion object {
        const val SETUP_BUSINESS_NAME_KEY = "setup-business-name-key"
        const val SETUP_BUSINESS_ADDRESS_KEY = "setup-business-address-key"
        const val SETUP_BUSINESS_CONTACT_KEY = "setup-business-contact-key"
        const val SETUP_PASSWORD_KEY = "setup-password-key"
    }
}