package com.kumar.nitinTechOnline.gstbilling

import android.content.Context
import android.database.Cursor
import com.kumar.nitinTechOnline.gstbilling.BillAdapter.BillItemClickListener
import android.support.v7.widget.RecyclerView
import com.kumar.nitinTechOnline.gstbilling.BillAdapter.BillHolder
import android.view.ViewGroup
import android.view.LayoutInflater
import android.view.View
import com.kumar.nitinTechOnline.gstbilling.R
import com.kumar.nitinTechOnline.gstbilling.data.GSTBillingContract.GSTBillingEntry
import com.kumar.nitinTechOnline.gstbilling.data.GSTBillingContract.GSTBillingCustomerEntry
import android.widget.TextView

class BillAdapter(
    private val mContext: Context,
    private val clickListener: BillItemClickListener,
    private var dividerColor: Int
) : RecyclerView.Adapter<BillHolder>() {
    private var mCursor: Cursor? = null

    interface BillItemClickListener {
        fun onBillItemClick(clickedBillId: String?, customerName: String?, phoneNumber: String?)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BillHolder {
        val view =
            LayoutInflater.from(mContext).inflate(R.layout.single_item_bills_layout, parent, false)
        return BillHolder(view)
    }

    override fun onBindViewHolder(holder: BillHolder, position: Int) {
        if (mCursor!!.moveToPosition(position)) {
            val id = mCursor!!.getLong(mCursor!!.getColumnIndex(GSTBillingEntry._ID))
            val customerName =
                mCursor!!.getString(mCursor!!.getColumnIndex(GSTBillingEntry.PRIMARY_COLUMN_NAME))
            val phoneNumber =
                mCursor!!.getString(mCursor!!.getColumnIndex(GSTBillingEntry.PRIMARY_COLUMN_PHONE_NUMBER))
            val date =
                mCursor!!.getString(mCursor!!.getColumnIndex(GSTBillingEntry.PRIMARY_COLUMN_DATE))
            val totalAmount = getTotalAmount(id)
            holder.customerNameTv.text = customerName
            if (phoneNumber.length == 10) {
                holder.phoneNumberTv.text = phoneNumber
            } else {
                holder.phoneNumberTv.text = ""
            }
            holder.totalAmountTv.text = mContext.getString(R.string.inr) + totalAmount.toString()
            holder.dateTv.text = date
            holder.itemView.setTag(R.id.bill_detail_id, id)
            holder.itemView.setTag(R.id.bill_detail_customer_name, customerName)
            holder.itemView.setTag(R.id.bill_detail_phone_number, phoneNumber)
            holder.divider.setBackgroundColor(dividerColor)
        }
    }

    private fun getTotalAmount(id: Long): Int {
        val amountCursor = mContext.contentResolver.query(
            GSTBillingEntry.CONTENT_URI.buildUpon().appendPath(id.toString()).build(),
            arrayOf(
                GSTBillingCustomerEntry.SECONDARY_COLUMN_FINAL_PRICE,
                GSTBillingCustomerEntry.SECONDARY_COLUMN_QUANTITY
            ),
            null,
            null,
            null
        )
        var totalAmount = 0
        val items = amountCursor.count
        for (i in 0 until items) {
            if (amountCursor.moveToPosition(i)) {
                val finalPrice = amountCursor.getFloat(0).toInt()
                val qty = amountCursor.getInt(1)
                totalAmount += finalPrice * qty
            }
        }
        amountCursor.close()
        return totalAmount
    }

    override fun getItemCount(): Int {
        return if (mCursor == null) {
            0
        } else {
            mCursor!!.count
        }
    }

    fun swapCursor(newCursor: Cursor?, newDividerColor: Int) {
        mCursor = newCursor
        dividerColor = newDividerColor
        notifyDataSetChanged()
    }

    inner class BillHolder(itemView: View) : RecyclerView.ViewHolder(itemView),
        View.OnClickListener {
        var customerNameTv: TextView
        var phoneNumberTv: TextView
        var totalAmountTv: TextView
        var dateTv: TextView
        var divider: View
        override fun onClick(v: View) {
            clickListener.onBillItemClick(
                itemView.getTag(R.id.bill_detail_id).toString(),
                itemView.getTag(R.id.bill_detail_customer_name) as String,
                itemView.getTag(R.id.bill_detail_phone_number) as String
            )
        }

        init {
            customerNameTv = itemView.findViewById(R.id.bill_customer_name) as TextView
            phoneNumberTv = itemView.findViewById(R.id.bill_phone_number) as TextView
            totalAmountTv = itemView.findViewById(R.id.bill_total_amount) as TextView
            dateTv = itemView.findViewById(R.id.bill_date) as TextView
            divider = itemView.findViewById(R.id.bill_divider)
            itemView.setOnClickListener(this)
        }
    }
}