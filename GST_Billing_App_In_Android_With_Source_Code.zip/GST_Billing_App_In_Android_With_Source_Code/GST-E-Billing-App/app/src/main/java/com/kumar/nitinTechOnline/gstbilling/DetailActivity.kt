package com.kumar.nitinTechOnline.gstbilling

import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.RecyclerView
import com.kumar.nitinTechOnline.gstbilling.DetailAdapter
import android.os.Bundle
import com.kumar.nitinTechOnline.gstbilling.R
import com.kumar.nitinTechOnline.gstbilling.DetailActivity
import com.kumar.nitinTechOnline.gstbilling.data.GSTBillingContract
import android.graphics.drawable.ColorDrawable
import android.support.v7.widget.LinearLayoutManager
import android.widget.TextView
import android.content.ContentValues
import android.content.Context
import android.widget.Toast
import android.content.Intent
import com.kumar.nitinTechOnline.gstbilling.SavePDFActivity
import android.widget.EditText
import android.text.method.PasswordTransformationMethod
import android.content.DialogInterface
import android.database.Cursor
import android.graphics.Color
import android.net.Uri
import android.preference.PreferenceManager
import android.support.v4.app.LoaderManager
import android.support.v4.content.CursorLoader
import android.support.v4.content.Loader
import android.support.v7.app.ActionBar
import android.support.v7.app.AlertDialog
import android.text.InputType
import android.view.Menu
import android.view.MenuItem
import com.kumar.nitinTechOnline.gstbilling.SetupPasswordActivity
import com.kumar.nitinTechOnline.gstbilling.NewBillActivity
import com.kumar.nitinTechOnline.gstbilling.utils.NumberToWord
import com.kumar.nitinTechOnline.gstbilling.DetailActivity.Companion.getDetailIntent as getDetailIntent1
class DetailActivity : AppCompatActivity(), LoaderManager.LoaderCallbacks<Cursor> {
    private var detailRecyclerView: RecyclerView? = null
    private var adapter: DetailAdapter? = null
    private var phoneNumber: String? = null
    private var customerName: String? = null
    private var itemCount = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        detailActionBar = supportActionBar
        getDetailIntent = intent
        billId = getDetailIntent1?.getStringExtra(GSTBillingContract.GSTBillingEntry._ID)
        if (getDetailIntent1!!.hasExtra(GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_STATUS)) {
            billStatus =
                getDetailIntent1?.getStringExtra(GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_STATUS)
        }
        if (billStatus == GSTBillingContract.BILL_STATUS_PAID) {
            detailActionBar!!.setBackgroundDrawable(ColorDrawable(Color.parseColor("#00C853")))
        } else {
            detailActionBar!!.setBackgroundDrawable(ColorDrawable(Color.RED))
        }
        if (getDetailIntent1!!.hasExtra(GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_NAME)) {
            customerName =
                getDetailIntent?.getStringExtra(GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_NAME)
            detailActionBar!!.setTitle(customerName)
        }
        if (getDetailIntent1!!.hasExtra(GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_PHONE_NUMBER)) {
            phoneNumber =
                getDetailIntent?.getStringExtra(GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_PHONE_NUMBER)
        }
        detailRecyclerView = findViewById(R.id.detail_recycler_view) as RecyclerView
        detailRecyclerView!!.layoutManager = LinearLayoutManager(this)
        detailRecyclerView!!.setHasFixedSize(true)
        adapter = DetailAdapter(this)
        detailRecyclerView!!.adapter = adapter
        totalTaxableValueTv = findViewById(R.id.total_amount_before_tax_value) as TextView
        totalCgstTv = findViewById(R.id.total_cgst_value) as TextView
        totalSgstTv = findViewById(R.id.total_sgst_value) as TextView
        totalGstTv = findViewById(R.id.total_gst_value) as TextView
        totalAmountTv = findViewById(R.id.total_amount_after_tax_value) as TextView
        totalAmountInWordsTv = findViewById(R.id.total_amount_in_words_value) as TextView
        inr = getString(R.string.inr) + " "
        supportLoaderManager.initLoader(DETAIL_LOADER_ID, null, this)
    }

    private fun markAsPaid() {
        val contentValues = ContentValues()
        contentValues.put(
            GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_STATUS,
            GSTBillingContract.BILL_STATUS_PAID
        )
        contentResolver.update(
            GSTBillingContract.GSTBillingEntry.CONTENT_URI.buildUpon().appendPath(billId.toString())
                .build(),
            contentValues,
            GSTBillingContract.GSTBillingEntry._ID + "=" + billId,
            null
        )
        Toast.makeText(this, getString(R.string.mark_as_paid_success), Toast.LENGTH_LONG).show()
        billStatus = GSTBillingContract.BILL_STATUS_PAID
        detailActionBar!!.setBackgroundDrawable(ColorDrawable(Color.parseColor("#00C853")))
        getDetailIntent1!!.putExtra(
            GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_STATUS,
            billStatus
        )
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_detail, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == R.id.action_mark_as_paid) {
            if (billStatus == GSTBillingContract.BILL_STATUS_UNPAID) {
                displayPasswordDialog(ACTION_MARK_AS_PAID_ID)
            } else {
                Toast.makeText(this, getString(R.string.marked_as_paid_already), Toast.LENGTH_LONG)
                    .show()
            }
        } else if (id == R.id.action_call_customer) {
            if (phoneNumber != null && phoneNumber!!.length == 10) {
                val callIntent = Intent(Intent.ACTION_VIEW)
                callIntent.data = Uri.parse("tel:+91$phoneNumber")
                startActivity(callIntent)
            } else {
                Toast.makeText(this, getString(R.string.no_phone_number_error), Toast.LENGTH_SHORT)
                    .show()
            }
        } else if (id == R.id.action_delete_bill) {
            if (billId != null && billId!!.length != 0) {
                displayPasswordDialog(ACTION_DELETE_BILL_ID)
            }
        } else if (id == R.id.action_add_more_items) {
            if (billId != null && billId!!.length != 0) {
                displayPasswordDialog(ACTION_ADD_MORE_ITEMS_ID)
            }
        } else if (id == R.id.action_save_to_pdf) {
            val pdfIntent = Intent(this, SavePDFActivity::class.java)
            pdfIntent.putExtra(GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_NAME, customerName)
            pdfIntent.putExtra(GSTBillingContract.GSTBillingEntry._ID, billId)
            pdfIntent.putExtra(ITEM_COUNT_KEY, itemCount)
            startActivity(pdfIntent)
        }
        return super.onOptionsItemSelected(item)
    }

    private fun deleteBill() {
        val rowsDeleted = contentResolver.delete(
            GSTBillingContract.GSTBillingEntry.CONTENT_URI.buildUpon().appendPath(
                billId
            ).build(), null, null
        )
        if (rowsDeleted == 1) {
            Toast.makeText(this, getString(R.string.delete_bill_success), Toast.LENGTH_SHORT).show()
            finish()
        } else {
            Toast.makeText(this, getString(R.string.delete_bill_error), Toast.LENGTH_SHORT).show()
        }
    }

    private fun displayPasswordDialog(actionId: Int) {
        var title = getString(R.string.action_mark_as_paid_label)
        if (actionId == ACTION_DELETE_BILL_ID) {
            title = getString(R.string.action_delete_bill_label)
        } else if (actionId == ACTION_ADD_MORE_ITEMS_ID) {
            title = getString(R.string.action_add_more_items_label)
        }
        val passwordInput = EditText(this)
        passwordInput.inputType =
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        passwordInput.transformationMethod = PasswordTransformationMethod.getInstance()
        passwordInput.setHint(R.string.enter_password_dialog_hint)
        passwordInput.setHintTextColor(Color.LTGRAY)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(passwordInput)
            .setPositiveButton(getString(R.string.enter_password_dialog_ok)) { dialog, which ->
                val password = passwordInput.text.toString()
                val savedPassword =
                    PreferenceManager.getDefaultSharedPreferences(this@DetailActivity)
                        .getString(SetupPasswordActivity.SETUP_PASSWORD_KEY, null)
                if (savedPassword != null && savedPassword == password) {
                    when (actionId) {
                        ACTION_MARK_AS_PAID_ID -> markAsPaid()
                        ACTION_DELETE_BILL_ID -> deleteBill()
                        ACTION_ADD_MORE_ITEMS_ID -> addMoreItems()
                        else -> Toast.makeText(
                            this@DetailActivity,
                            getString(R.string.no_operation_specified_error),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this@DetailActivity,
                        getString(R.string.invalid_password_error),
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            .setNegativeButton(getString(R.string.enter_password_dialog_cancel)) { dialog, which -> }
            .show()
    }

    private fun addMoreItems() {
        val addIntent = Intent(this, NewBillActivity::class.java)
        addIntent.putExtra(ADDING_MORE_ITEMS, true)
        addIntent.putExtra(GSTBillingContract.GSTBillingEntry._ID, billId)
        addIntent.putExtra(GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_NAME, customerName)
        addIntent.putExtra(
            GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_PHONE_NUMBER,
            phoneNumber
        )
        startActivity(addIntent)
    }

    override fun onCreateLoader(id: Int, args: Bundle): Loader<Cursor> {
        return CursorLoader(
            this,
            GSTBillingContract.GSTBillingEntry.CONTENT_URI.buildUpon().appendPath(billId).build(),
            null,
            null,
            null,
            null
        )
    }

    override fun onLoadFinished(loader: Loader<Cursor>, data: Cursor) {
        adapter!!.swapCursor(data)
        itemCount = data.count
    }

    override fun onLoaderReset(loader: Loader<Cursor>) {
        adapter!!.swapCursor(null)
        itemCount = 0
    }

    companion object {
        private const val DETAIL_LOADER_ID = 44
        private const val ACTION_MARK_AS_PAID_ID = 400
        private const val ACTION_DELETE_BILL_ID = 401
        private const val ACTION_ADD_MORE_ITEMS_ID = 402
        const val ADDING_MORE_ITEMS = "adding-more-items-to-bill"
        const val EDITING_ITEM = "editing-existing-item"
        private var billId: String? = null
        private var billStatus: String? = null
        private var totalTaxableValueTv: TextView? = null
        private var totalCgstTv: TextView? = null
        private var totalSgstTv: TextView? = null
        private var totalGstTv: TextView? = null
        private var totalAmountTv: TextView? = null
        private var totalAmountInWordsTv: TextView? = null
        private var inr: String? = null
        const val ITEM_COUNT_KEY = "items-count-in-bill"
        private var detailActionBar: ActionBar? = null
        private var getDetailIntent: Intent? = null
        @JvmStatic
        fun printTotalDetails(totalTaxableValue: Float, totalSingleGst: Float, totalAmount: Float) {
            totalTaxableValueTv!!.text = inr + String.format("%.2f", totalTaxableValue)
            totalCgstTv!!.text = inr + String.format("%.2f", totalSingleGst)
            totalSgstTv!!.text = inr + String.format("%.2f", totalSingleGst)
            totalGstTv!!.text =
                inr + String.format(
                    "%.2f",
                    totalSingleGst + totalSingleGst
                )
            totalAmountTv!!.text = inr + String.format("%.2f", totalAmount)
            totalAmountInWordsTv!!.text =
                "Rupees. " + NumberToWord.getNumberInWords(totalAmount.toInt().toString())
        }

        @JvmStatic
        fun editItem(
            context: Context,
            id: Int,
            itemDescription: String?,
            finalPrice: Float,
            quantity: Int
        ) {
            val passwordInput = EditText(context)
            passwordInput.inputType =
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            passwordInput.transformationMethod = PasswordTransformationMethod.getInstance()
            passwordInput.setHint(R.string.enter_password_dialog_hint)
            passwordInput.setHintTextColor(Color.LTGRAY)
            AlertDialog.Builder(context)
                .setTitle(context.getString(R.string.action_edit_bill_item_label))
                .setView(passwordInput)
                .setPositiveButton(context.getString(R.string.enter_password_dialog_ok)) { dialog, which ->
                    val password = passwordInput.text.toString()
                    val savedPassword = PreferenceManager.getDefaultSharedPreferences(context)
                        .getString(SetupPasswordActivity.SETUP_PASSWORD_KEY, null)
                    if (savedPassword != null && savedPassword == password) {
                        val editIntent = Intent(context, NewBillActivity::class.java)
                        editIntent.putExtra(EDITING_ITEM, billId)
                        editIntent.putExtra(GSTBillingContract.GSTBillingCustomerEntry._ID, id)
                        editIntent.putExtra(
                            GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_COLUMN_ITEM_DESCRIPTION,
                            itemDescription
                        )
                        editIntent.putExtra(
                            GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_COLUMN_FINAL_PRICE,
                            finalPrice
                        )
                        editIntent.putExtra(
                            GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_COLUMN_QUANTITY,
                            quantity
                        )
                        context.startActivity(editIntent)
                    } else {
                        Toast.makeText(
                            context,
                            context.getString(R.string.invalid_password_error),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
                .setNegativeButton(context.getString(R.string.enter_password_dialog_cancel)) { dialog, which -> }
                .show()
        }

        @JvmStatic
        fun changeBillStatus() {
            billStatus = GSTBillingContract.BILL_STATUS_UNPAID
            detailActionBar!!.setBackgroundDrawable(ColorDrawable(Color.RED))
            getDetailIntent1!!.putExtra(
                GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_STATUS,
                billStatus
            )
        }
    }
}