package com.kumar.nitinTechOnline.gstbilling.data

import android.content.ContentProvider
import com.kumar.nitinTechOnline.gstbilling.data.GSTBillingDbHelper
import android.database.sqlite.SQLiteDatabase
import com.kumar.nitinTechOnline.gstbilling.data.GSTBillingContentProvider
import com.kumar.nitinTechOnline.gstbilling.data.GSTBillingContract
import android.content.ContentValues
import android.content.ContentUris
import com.kumar.nitinTechOnline.gstbilling.NewBillActivity
import android.content.UriMatcher
import android.database.Cursor
import android.database.SQLException
import android.net.Uri
import java.lang.UnsupportedOperationException

/**
 * Created by Ajay on 7/23/2017.
 */
class GSTBillingContentProvider : ContentProvider() {
    private var mBillingDbHelper: GSTBillingDbHelper? = null
    override fun onCreate(): Boolean {
        val context = context
        mBillingDbHelper = GSTBillingDbHelper(context)
        return true
    }

    override fun query(
        uri: Uri,
        projection: Array<String>,
        selection: String,
        selectionArgs: Array<String>,
        sortOrder: String
    ): Cursor? {
        val db = mBillingDbHelper!!.readableDatabase
        val match = sUriMatcher.match(uri)
        val retCursor: Cursor
        when (match) {
            BILLS -> {
                retCursor = db.query(
                    GSTBillingContract.GSTBillingEntry.PRIMARY_TABLE_NAME,
                    projection,
                    selection,
                    selectionArgs,
                    null,
                    null,
                    sortOrder
                )
                retCursor.setNotificationUri(context.contentResolver, uri)
            }
            BILL_WITH_ID -> {
                retCursor = db.query(
                    GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_TABLE_NAME + uri.lastPathSegment,
                    projection,
                    selection,
                    selectionArgs,
                    null,
                    null,
                    sortOrder
                )
                retCursor.setNotificationUri(
                    context.contentResolver,
                    GSTBillingContract.BASE_CONTENT_URI.buildUpon()
                        .appendPath(GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_TABLE_NAME + uri.lastPathSegment)
                        .build()
                )
            }
            else -> throw UnsupportedOperationException("Unknown uri: $uri")
        }
        return retCursor
    }

    override fun getType(uri: Uri): String? {
        return null
    }

    override fun insert(uri: Uri, values: ContentValues): Uri? {
        val db = mBillingDbHelper!!.writableDatabase
        val match = sUriMatcher.match(uri)
        val returnUri: Uri
        returnUri = when (match) {
            BILLS -> {
                val id =
                    db.insert(GSTBillingContract.GSTBillingEntry.PRIMARY_TABLE_NAME, null, values)
                if (id > 0) {
                    ContentUris.withAppendedId(GSTBillingContract.GSTBillingEntry.CONTENT_URI, id)
                } else {
                    throw SQLException("Failed to insert row into : $uri")
                }
            }
            else -> throw UnsupportedOperationException("Unknown uri: $uri")
        }
        context.contentResolver.notifyChange(uri, null)
        return returnUri
    }

    override fun bulkInsert(uri: Uri, values: Array<ContentValues>): Int {
        val db = mBillingDbHelper!!.writableDatabase
        val match = sUriMatcher.match(uri)
        return when (match) {
            BILL_WITH_ID -> {
                if (NewBillActivity.addingMoreItems == false) {
                    GSTBillingDbHelper.createBillTable(db, uri.lastPathSegment)
                }
                db.beginTransaction()
                var rowsInserted = 0
                try {
                    for (value in values) {
                        val _id = db.insert(
                            GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_TABLE_NAME + uri.lastPathSegment,
                            null,
                            value
                        )
                        if (_id != -1L) {
                            rowsInserted++
                        }
                    }
                    db.setTransactionSuccessful()
                } finally {
                    db.endTransaction()
                }
                if (rowsInserted > 0) {
                    context.contentResolver.notifyChange(
                        GSTBillingContract.BASE_CONTENT_URI.buildUpon()
                            .appendPath(GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_TABLE_NAME + uri.lastPathSegment)
                            .build(), null
                    )
                }
                rowsInserted
            }
            else -> super.bulkInsert(uri, values)
        }
    }

    override fun delete(uri: Uri, selection: String, selectionArgs: Array<String>): Int {
        val db = mBillingDbHelper!!.writableDatabase
        val match = sUriMatcher.match(uri)
        var rowsDeleted = 0
        when (match) {
            BILL_WITH_ID -> {
                try {
                    db.beginTransaction()
                    GSTBillingDbHelper.dropBillTable(db, uri.lastPathSegment)
                    rowsDeleted = db.delete(
                        GSTBillingContract.GSTBillingEntry.PRIMARY_TABLE_NAME,
                        GSTBillingContract.GSTBillingEntry._ID + "=" + uri.lastPathSegment,
                        selectionArgs
                    )
                    db.setTransactionSuccessful()
                } finally {
                    db.endTransaction()
                }
                if (rowsDeleted > 0) {
                    context.contentResolver.notifyChange(
                        GSTBillingContract.GSTBillingEntry.CONTENT_URI,
                        null
                    )
                }
            }
            else -> throw UnsupportedOperationException("Unknown uri: $uri")
        }
        return rowsDeleted
    }

    override fun update(
        uri: Uri,
        values: ContentValues,
        selection: String,
        selectionArgs: Array<String>
    ): Int {
        val db = mBillingDbHelper!!.writableDatabase
        val match = sUriMatcher.match(uri)
        var rowsUpdated = 0
        when (match) {
            BILL_WITH_ID -> {
                rowsUpdated = db.update(
                    GSTBillingContract.GSTBillingEntry.PRIMARY_TABLE_NAME,
                    values,
                    selection,
                    selectionArgs
                )
                if (rowsUpdated > 0) {
                    context.contentResolver.notifyChange(
                        GSTBillingContract.GSTBillingEntry.CONTENT_URI,
                        null
                    )
                }
            }
            BILL_WITH_ID_WITH_ID -> {
                rowsUpdated = db.update(
                    GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_TABLE_NAME + uri.pathSegments[1],
                    values,
                    GSTBillingContract.GSTBillingCustomerEntry._ID + "=" + uri.lastPathSegment,
                    null
                )
                if (rowsUpdated > 0) {
                    context.contentResolver.notifyChange(
                        GSTBillingContract.BASE_CONTENT_URI.buildUpon()
                            .appendPath(GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_TABLE_NAME + uri.pathSegments[1])
                            .build(), null
                    )
                    context.contentResolver.notifyChange(
                        GSTBillingContract.GSTBillingEntry.CONTENT_URI,
                        null
                    )
                }
            }
            else -> throw UnsupportedOperationException("Unknown uri: $uri")
        }
        return rowsUpdated
    }

    companion object {
        const val BILLS = 100
        const val BILL_WITH_ID = 101
        const val BILL_WITH_ID_WITH_ID = 102
        private val sUriMatcher = buildUriMatcher()
        private fun buildUriMatcher(): UriMatcher {
            val uriMatcher = UriMatcher(UriMatcher.NO_MATCH)
            uriMatcher.addURI(GSTBillingContract.AUTHORITY, GSTBillingContract.PATH_BILLS, BILLS)
            uriMatcher.addURI(
                GSTBillingContract.AUTHORITY,
                GSTBillingContract.PATH_BILLS + "/#",
                BILL_WITH_ID
            )
            uriMatcher.addURI(
                GSTBillingContract.AUTHORITY,
                GSTBillingContract.PATH_BILLS + "/#/#",
                BILL_WITH_ID_WITH_ID
            )
            return uriMatcher
        }
    }
}