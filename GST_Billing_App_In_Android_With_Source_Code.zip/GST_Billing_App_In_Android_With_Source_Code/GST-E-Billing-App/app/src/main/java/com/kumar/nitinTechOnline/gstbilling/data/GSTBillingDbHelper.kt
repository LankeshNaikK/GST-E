package com.kumar.nitinTechOnline.gstbilling.data

import android.content.Context
import android.database.sqlite.SQLiteOpenHelper
import com.kumar.nitinTechOnline.gstbilling.data.GSTBillingDbHelper
import android.database.sqlite.SQLiteDatabase
import com.kumar.nitinTechOnline.gstbilling.data.GSTBillingContract

class GSTBillingDbHelper(context: Context?) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        val CREATE_TABLE =
            "CREATE TABLE " + GSTBillingContract.GSTBillingEntry.PRIMARY_TABLE_NAME + " (" +
                    GSTBillingContract.GSTBillingEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_NAME + " TEXT NOT NULL, " +
                    GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_PHONE_NUMBER + " TEXT NOT NULL, " +
                    GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_DATE + " TEXT NOT NULL, " +
                    GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_STATUS + " TEXT NOT NULL);"
        db.execSQL(CREATE_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    companion object {
        private const val DATABASE_NAME = "GSTBillsDB.db"
        private const val VERSION = 1
        fun createBillTable(db: SQLiteDatabase, billId: String) {
            val CREATE_TABLE =
                "CREATE TABLE " + GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_TABLE_NAME + billId + " (" +
                        GSTBillingContract.GSTBillingCustomerEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_COLUMN_ITEM_DESCRIPTION + " TEXT NOT NULL, " +
                        GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_COLUMN_FINAL_PRICE + " REAL NOT NULL, " +
                        GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_COLUMN_QUANTITY + " INTEGER NOT NULL, " +
                        GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_COLUMN_TAX_SLAB + " INTEGER NOT NULL);"
            db.execSQL(CREATE_TABLE)
        }

        fun dropBillTable(db: SQLiteDatabase, billId: String) {
            val DROP_TABLE =
                "DROP TABLE IF EXISTS " + GSTBillingContract.GSTBillingCustomerEntry.SECONDARY_TABLE_NAME + billId
            db.execSQL(DROP_TABLE)
        }
    }
}