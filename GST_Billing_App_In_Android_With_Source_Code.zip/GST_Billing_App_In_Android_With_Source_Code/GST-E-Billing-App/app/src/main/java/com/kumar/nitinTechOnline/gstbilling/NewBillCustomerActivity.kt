package com.kumar.nitinTechOnline.gstbilling

import android.support.v7.app.AppCompatActivity
import android.widget.EditText
import android.os.Bundle
import com.kumar.nitinTechOnline.gstbilling.R
import android.widget.Toast
import android.content.Intent
import android.view.Menu
import android.view.MenuItem
import android.view.View
import com.kumar.nitinTechOnline.gstbilling.NewBillActivity
import com.kumar.nitinTechOnline.gstbilling.NewBillCustomerActivity

class NewBillCustomerActivity : AppCompatActivity() {
    private var customerNameEt: EditText? = null
    private var phoneNumberEt: EditText? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_bill_customer)
        customerNameEt = findViewById(R.id.customer_name_value) as EditText
        phoneNumberEt = findViewById(R.id.phone_number_value) as EditText
    }

    fun addCustomer(view: View?) {
        val customerName = customerNameEt!!.text.toString()
        var phoneNumber = phoneNumberEt!!.text.toString()
        if (customerName.length == 0) {
            Toast.makeText(this, getString(R.string.enter_customer_name_error), Toast.LENGTH_SHORT)
                .show()
            return
        }
        if (phoneNumber.length > 0 && phoneNumber.length < 10) {
            Toast.makeText(this, getString(R.string.invalid_phone_number_error), Toast.LENGTH_SHORT)
                .show()
            return
        } else if (phoneNumber.length == 0) {
            phoneNumber = "NA"
        }
        val intent = Intent(this, NewBillActivity::class.java)
        intent.putExtra(ADD_CUSTOMER_NAME_KEY, customerName)
        intent.putExtra(ADD_CUSTOMER_PHONE_KEY, phoneNumber)
        startActivity(intent)
        finish()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_bill, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == R.id.action_discard) {
            finish()
        }
        return super.onOptionsItemSelected(item)
    }

    companion object {
        const val ADD_CUSTOMER_NAME_KEY = "customerName"
        const val ADD_CUSTOMER_PHONE_KEY = "phoneNumber"
    }
}