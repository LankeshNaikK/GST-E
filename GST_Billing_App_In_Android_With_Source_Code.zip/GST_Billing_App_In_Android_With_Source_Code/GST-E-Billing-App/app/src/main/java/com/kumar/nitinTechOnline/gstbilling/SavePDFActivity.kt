package com.kumar.nitinTechOnline.gstbilling

import android.support.v7.app.AppCompatActivity
import android.widget.TextView
import android.support.v7.widget.RecyclerView
import android.content.Intent
import android.os.Bundle
import com.kumar.nitinTechOnline.gstbilling.R
import com.kumar.nitinTechOnline.gstbilling.SavePDFActivity
import com.kumar.nitinTechOnline.gstbilling.data.GSTBillingContract
import com.kumar.nitinTechOnline.gstbilling.DetailActivity
import android.content.SharedPreferences
import android.preference.PreferenceManager
import com.kumar.nitinTechOnline.gstbilling.SetupPasswordActivity
import android.os.Build
import com.kumar.nitinTechOnline.gstbilling.utils.PDFUtils
import android.support.v7.widget.LinearLayoutManager
import com.kumar.nitinTechOnline.gstbilling.SavePDFAdapter
import android.support.annotation.RequiresApi
import android.app.Activity
import android.content.ContentResolver
import android.database.Cursor
import android.os.Handler
import android.view.Menu
import android.view.MenuItem
import com.kumar.nitinTechOnline.gstbilling.utils.NumberToWord


class SavePDFActivity : AppCompatActivity() {
    private var customerNameTv: TextView? = null
    private var invoiceDateTv: TextView? = null
    private var businessNameTv: TextView? = null
    private var businessAddressTv: TextView? = null
    private var authorisedSignatoryTv: TextView? = null
    private var businessContactTv: TextView? = null
    private var pdfRecyclerView: RecyclerView? = null
    private var getPDFIntent: Intent? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_save_pdf)
        thisActivity = this
        getPDFIntent = intent
        customerName =
            getPDFIntent?.getStringExtra(GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_NAME)
        billId = getPDFIntent?.getStringExtra(GSTBillingContract.GSTBillingEntry._ID)
        totalItems = getPDFIntent?.getIntExtra(DetailActivity.ITEM_COUNT_KEY, 0)!!
        totalPages = Math.ceil(totalItems.toDouble() / MAX_ITEMS_PER_PAGE).toInt()
        pageNumber = 0
        customerNameTv = findViewById(R.id.pdf_customer_name) as TextView
        invoiceDateTv = findViewById(R.id.pdf_invoice_date) as TextView
        businessNameTv = findViewById(R.id.pdf_business_name) as TextView
        businessAddressTv = findViewById(R.id.pdf_business_address) as TextView
        authorisedSignatoryTv = findViewById(R.id.pdf_authorised_signatory) as TextView
        businessContactTv = findViewById(R.id.pdf_business_contact) as TextView
        totalQtyTv = findViewById(R.id.pdf_total_qty) as TextView
        totalTaxableValueTv = findViewById(R.id.pdf_total_taxable_value) as TextView
        totalCgstTv = findViewById(R.id.pdf_total_cgst) as TextView
        totalSgstTv = findViewById(R.id.pdf_total_sgst) as TextView
        totalAmountBeforeTaxTv = findViewById(R.id.pdf_total_amount_before_tax) as TextView
        totalTaxAmountTv = findViewById(R.id.pdf_total_gst) as TextView
        totalAmountAfterTaxTv = findViewById(R.id.pdf_total_amount_after_tax) as TextView
        totalAmountInWordsTv = findViewById(R.id.pdf_total_amount_in_words) as TextView
        billPageNumber = findViewById(R.id.pdf_bill_page_number) as TextView
        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        businessNameTv!!.text =
            prefs.getString(
                SetupPasswordActivity.SETUP_BUSINESS_NAME_KEY,
                getString(R.string.app_name)
            )
        businessAddressTv!!.text =
            prefs.getString(SetupPasswordActivity.SETUP_BUSINESS_ADDRESS_KEY, "Address")
        val authorisedSignatory = "For " + prefs.getString(
            SetupPasswordActivity.SETUP_BUSINESS_NAME_KEY,
            getString(R.string.app_name)
        )
        authorisedSignatoryTv!!.text = authorisedSignatory
        businessContactTv!!.text =
            prefs.getString(SetupPasswordActivity.SETUP_BUSINESS_CONTACT_KEY, "")
        customerNameTv!!.text = customerName
        val billDateCursor = contentResolver.query(
            GSTBillingContract.GSTBillingEntry.CONTENT_URI,
            arrayOf(GSTBillingContract.GSTBillingEntry.PRIMARY_COLUMN_DATE),
            GSTBillingContract.GSTBillingEntry._ID + "=" + billId,
            null,
            null
        )
        billDateCursor.moveToFirst()
        val billDate = billDateCursor.getString(0)
        invoiceDateTv!!.text = billDate
        inr = getString(R.string.inr) + " "
        Companion.contentResolver = contentResolver
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            pdfMaker = PDFUtils()
        }
        itemsShown = 0
        pdfCursor = updatePdfCursor()
        pdfRecyclerView = findViewById(R.id.pdf_recycler_view) as RecyclerView
        pdfRecyclerView!!.layoutManager = LinearLayoutManager(this)
        pdfRecyclerView!!.setHasFixedSize(true)
        adapter = SavePDFAdapter(this, pdfCursor)
        pdfRecyclerView!!.adapter = adapter
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_save_pdf, menu)
        return true
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        when (id) {
            R.id.action_save_pdf_file -> automaticSavePDF()
        }
        return super.onOptionsItemSelected(item)
    }

    companion object {
        private var thisActivity: Activity? = null
        private const val MAX_ITEMS_PER_PAGE = 32
        private var pdfCursor: Cursor? = null
        private var totalItems = 0
        private var itemsShown = 0
        private var pdfMaker: PDFUtils? = null
        private var moreItemsPresent = false
        private var totalPages = 0
        private var pageNumber = 0
        private var customerName: String? = null
        private var billId: String? = null
        private var totalQtyTv: TextView? = null
        private var totalTaxableValueTv: TextView? = null
        private var totalCgstTv: TextView? = null
        private var totalSgstTv: TextView? = null
        private var totalAmountBeforeTaxTv: TextView? = null
        private var totalTaxAmountTv: TextView? = null
        private var totalAmountAfterTaxTv: TextView? = null
        private var totalAmountInWordsTv: TextView? = null
        private var billPageNumber: TextView? = null
        private var adapter: SavePDFAdapter? = null
        private var contentResolver: ContentResolver? = null
        private var inr: String? = null
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        private fun automaticSavePDF() {
            pdfMaker!!.addPageToPDF(thisActivity!!.findViewById(R.id.pdf_view))
            if (moreItemsPresent) {
                pdfCursor = updatePdfCursor()
                adapter!!.swapCursor(pdfCursor)
            } else {
                pdfMaker!!.createPdf(thisActivity, billId + " " + customerName)
                thisActivity!!.finish()
            }
        }

        private fun updatePdfCursor(): Cursor {
            val cursor = contentResolver!!.query(
                GSTBillingContract.GSTBillingEntry.CONTENT_URI.buildUpon().appendPath(billId)
                    .build(),
                null,
                GSTBillingContract.GSTBillingCustomerEntry._ID + " between " + (itemsShown + 1) + " and " + (itemsShown + MAX_ITEMS_PER_PAGE),
                null,
                GSTBillingContract.GSTBillingCustomerEntry._ID
            )
            itemsShown += MAX_ITEMS_PER_PAGE
            moreItemsPresent = areMoreItemsPresent()
            setBillPageNumber()
            return cursor
        }

        fun areMoreItemsPresent(): Boolean {
            return if (totalItems - itemsShown > 0) {
                true
            } else {
                false
            }
        }

        private fun setBillPageNumber() {
            pageNumber++
            billPageNumber!!.text =
                "Page " + pageNumber + " of " + totalPages
        }

        @RequiresApi(Build.VERSION_CODES.KITKAT)
        @JvmStatic
        fun printTotalDetails(
            totalQty: Int,
            totalTaxableValue: Float,
            totalSingleGst: Float,
            totalAmount: Float
        ) {
            totalQtyTv!!.text = totalQty.toString()
            totalTaxableValueTv!!.text =
                String.format("%.2f", totalTaxableValue)
            totalCgstTv!!.text = String.format("%.2f", totalSingleGst)
            totalSgstTv!!.text = String.format("%.2f", totalSingleGst)
            totalAmountBeforeTaxTv!!.text =
                inr + String.format("%.2f", totalTaxableValue)
            totalTaxAmountTv!!.text =
                inr + String.format(
                    "%.2f",
                    totalSingleGst + totalSingleGst
                )
            totalAmountAfterTaxTv!!.text = inr + String.format("%.2f", totalAmount)
            totalAmountInWordsTv!!.text =
                "Rupees. " + NumberToWord.getNumberInWords(totalAmount.toInt().toString())
            Handler().postDelayed({ if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                automaticSavePDF()
            }
            }, 1000)
        }
    }
}